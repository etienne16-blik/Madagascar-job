const sb=supabase.createClient(CFG.SUPABASE_URL,CFG.SUPABASE_ANON_KEY);
const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const ar=n=>Number(n||0).toLocaleString('fr-FR')+' Ar';
const dt=d=>new Date(d).toLocaleString('fr-FR',{dateStyle:'short',timeStyle:'short'});
const url=u=>/^https?:\/\//i.test(u||'')?esc(u):'';
const ST={pending:'En attente',approved:'Approuvé',rejected:'Rejeté',draft:'Paiement requis',active:'Active',paused:'En pause',ended:'Terminée',suspended:'Suspendu',hidden:'Masquée'};
const badge=s=>`<span class="b ${esc(s)}">${ST[s]||esc(s)}</span>`;
const routes={};let me=null,isAdmin=false;
function toast(m,err){const t=$('#toast');t.textContent=m;t.className='show'+(err?' err':'');setTimeout(()=>t.className='',3200)}
async function call(fn,args){const{data,error}=await sb.rpc(fn,args||{});if(error){toast(error.message,1);throw error}return data}
function view(h){$('#app').innerHTML=h}
function modal(h){$('#modal').innerHTML=`<div class="sheet">${h}<button class="btn ghost" onclick="closeModal()">Fermer</button></div>`;$('#modal').classList.add('open')}
function closeModal(){$('#modal').classList.remove('open')}
async function upload(file,bucket='proofs'){if(!file||!file.size)return null;const p=`${me.id}/${Date.now()}_${file.name.replace(/[^\w.]/g,'_')}`;const{error}=await sb.storage.from(bucket).upload(p,file);if(error){toast(error.message,1);throw error}return bucket==='media'?sb.storage.from('media').getPublicUrl(p).data.publicUrl:p}
async function signed(p){const{data}=await sb.storage.from('proofs').createSignedUrl(p,3600);return data?.signedUrl||''}
document.addEventListener('click',async e=>{const b=e.target.closest('[data-fn]');if(!b)return;if(b.dataset.c&&!confirm(b.dataset.c))return;
 try{await call(b.dataset.fn,JSON.parse(b.dataset.a||'{}'));toast('Fait ✔');await loadMe();render()}catch{}});
const A=(fn,args,label,cls='',c='')=>`<button class="btn sm ${cls}" data-fn="${fn}" data-a='${esc(JSON.stringify(args))}' ${c?`data-c="${esc(c)}"`:''}>${label}</button>`;
async function loadMe(){const uid=(await sb.auth.getUser()).data.user.id;let{data}=await sb.from('profiles').select('*').eq('id',uid).maybeSingle();
 if(!data){await sb.rpc('ensure_profile');data=(await sb.from('profiles').select('*').eq('id',uid).maybeSingle()).data}
 if(!data)toast('Profil introuvable : exécutez sql/schema.sql dans Supabase',1);me=data;isAdmin=!!(await sb.rpc('is_admin')).data}
async function boot(){if(/VOTRE/.test(CFG.SUPABASE_URL+CFG.SUPABASE_ANON_KEY)){view('<div class="card warn">Configurez <b>js/config.js</b> (SUPABASE_URL et SUPABASE_ANON_KEY).</div>');return}
 const{data:{session}}=await sb.auth.getSession();if(session)await loadMe();addEventListener('hashchange',render);render()}
async function render(){closeModal();if(!me){$('#nav').innerHTML='';$('#who').textContent='';return authView()}
 $('#who').textContent=me.full_name||me.email;
 if(me.status!=='active'){$('#nav').innerHTML='';return view(`<div class="card"><h2>Compte suspendu</h2><p>Contactez l'administration.</p></div><button class="btn" onclick="logout()">Déconnexion</button>`)}
 const biz=me.account_type==='business';const r=location.hash.split('/')[1]||(biz?'biz':'home');
 const items=biz?[['biz','📢','Campagnes'],['wallet','💰','Paiements'],['profile','👤','Profil']]:[['home','🏠','Missions'],['wallet','💰','Portefeuille'],...(isAdmin?[['admin','🛡️','Admin']]:[]),['profile','👤','Profil']];
 $('#nav').innerHTML=items.map(([k,i,l])=>`<a href="#/${k}" class="${k==r?'on':''}">${i}<br>${l}</a>`).join('');
 try{await(routes[r]||routes[biz?'biz':'home'])()}catch(e){console.error(e)}}
async function logout(){await sb.auth.signOut();me=null;isAdmin=false;location.hash='';render()}
let mode='login';
function authView(){view(`<div class="card"><h2>${mode=='login'?'Connexion':'Inscription'}</h2>
<form onsubmit="authGo(event)">
${mode=='reg'?`<select name="t"><option value="user">Compte utilisateur</option><option value="business">Compte entreprise</option></select><input name="n" placeholder="Nom complet ou nom de l'entreprise" required>`:''}
<input name="e" type="email" placeholder="Email" required autocomplete="email"><input name="p" type="password" placeholder="Mot de passe (6+ caractères)" minlength="6" required>
<button class="btn gold">${mode=='login'?'Se connecter':'Créer mon compte'}</button></form>
<button class="btn ghost" onclick="mode=mode=='login'?'reg':'login';authView()">${mode=='login'?"Pas de compte ? S'inscrire":'Déjà inscrit ? Se connecter'}</button></div>
<div class="card warn">Les soldes et retraits de MADA JOBS sont virtuels (simulation).</div>`)}
async function authGo(e){e.preventDefault();const f=new FormData(e.target);let r;
 if(mode=='login')r=await sb.auth.signInWithPassword({email:f.get('e'),password:f.get('p')});
 else r=await sb.auth.signUp({email:f.get('e'),password:f.get('p'),options:{data:{full_name:f.get('n'),account_type:f.get('t')}}});
 if(r.error)return toast(r.error.message,1);
 if(!r.data.session)return toast('Compte créé : confirmez votre email puis connectez-vous.');
 await loadMe();location.hash='';render()}
let T=[];
routes.home=async()=>{const day=new Date().toISOString().slice(0,10);
 const[t,c]=await Promise.all([sb.from('tasks').select('*').eq('active',true).order('id'),sb.from('task_completions').select('*').eq('user_id',me.id).order('id',{ascending:false}).limit(30)]);
 T=t.data||[];const done=(c.data||[]).filter(x=>x.completed_on===day&&x.status!=='rejected');const dm=new Set(done.map(x=>x.task_id));
 view(`<div class="card bal"><small>Solde virtuel (simulation)</small><b>${ar(me.balance)}</b>Aujourd'hui : ${done.length}/5 missions</div>
 <h2>Missions disponibles</h2>${T.map(x=>`<div class="card click" onclick="${dm.has(x.id)?'':`openTask(${x.id})`}"><div class="row"><b>${esc(x.title)}</b><span class="pos">+${ar(x.reward)}</span></div><small>${{social:'Publication réseau social',video:'Vidéo sponsorisée',screenshot:"Capture d'écran",ad:'Publicité'}[x.type]||''}</small>${dm.has(x.id)?' <span class="b">Déjà soumise</span>':''}</div>`).join('')||'<p class="muted">Aucune mission pour le moment.</p>'}
 <h2>Historique</h2>${(c.data||[]).map(x=>`<div class="card row"><span>${esc(T.find(y=>y.id==x.task_id)?.title||'Mission #'+x.task_id)}<br><small>${dt(x.created_at)}</small></span>${badge(x.status)}</div>`).join('')||'<p class="muted">Rien pour le moment.</p>'}`)};
function media(u){if(!url(u))return'';return /\.(mp4|webm)(\?|$)/i.test(u)?`<video src="${url(u)}" controls playsinline></video>`:`<img src="${url(u)}" alt="">`}
window.openTask=id=>{const t=T.find(x=>x.id==id);const v=t.type==='video';
 modal(`<h3>${esc(t.title)}</h3><p>${esc(t.description)}</p>${media(t.media_url)}${url(t.url)?`<a class="btn ghost" target="_blank" rel="noopener noreferrer" href="${url(t.url)}">Ouvrir le lien</a>`:''}
 ${v?`<button class="btn" id="sv">▶ Démarrer le visionnage (${t.duration_seconds}s)</button><p id="cd" class="muted"></p>`:''}
 <textarea id="pt" placeholder="${t.type==='social'?'Lien de votre publication':'Note (facultatif)'}"></textarea>
 ${v?'':'<input type="file" id="pf" accept="image/*">'}<button class="btn gold" id="sub" ${v?'disabled':''}>Envoyer pour validation</button>
 <small>Récompense versée après validation par l'administrateur.</small>`);
 if(v)$('#sv').onclick=async()=>{try{await call('start_video',{p_task:id})}catch{return}$('#sv').disabled=true;let s=t.duration_seconds;const i=setInterval(()=>{$('#cd').textContent=s>0?`Patientez ${s}s…`:'Visionnage terminé, vous pouvez envoyer.';if(s--<=0){clearInterval(i);$('#sub').disabled=false}},1000)};
 $('#sub').onclick=async()=>{try{const path=await upload($('#pf')?.files[0]);await call('submit_task',{p_task:id,p_proof:$('#pt').value.trim()||null,p_path:path});toast('Envoyée ! En attente de validation.');render()}catch{}}};
function payInfo(){return`<div class="card warn">Paiement MVola<br><b>Numéro MVola : ${CFG.MVOLA_NUM}</b><br>Nom : ${CFG.MVOLA_NAME}.<br><small>Envoyez le montant puis soumettez la référence ou la capture. L'administrateur vérifie manuellement.</small></div>`}
function depForm(camp,amt){return`${payInfo()}<form onsubmit="dep(event,${camp||'null'})"><input name="a" type="number" min="1000" placeholder="Montant (Ar)" value="${amt||''}" required><input name="r" placeholder="Référence de la transaction MVola"><input name="f" type="file" accept="image/*"><button class="btn gold">Soumettre la preuve</button></form>`}
async function dep(e,camp){e.preventDefault();const f=new FormData(e.target);try{const path=await upload(f.get('f'));await call('submit_deposit',{p_amount:+f.get('a'),p_method:'mvola',p_ref:f.get('r')||null,p_path:path,p_campaign:camp});toast('Preuve envoyée');closeModal();render()}catch{}}
routes.wallet=async()=>{const q=t=>sb.from(t).select('*').eq('user_id',me.id).order('id',{ascending:false}).limit(20);
 const[tx,wd,dp]=await Promise.all([q('wallet_transactions'),q('withdrawals'),q('deposits')]);const biz=me.account_type==='business';
 view(`${biz?'':`<div class="card bal"><small>Solde virtuel (simulation, aucun argent réel versé)</small><b>${ar(me.balance)}</b></div>
 <div class="card"><h3>Retrait (min. 20 000 Ar)</h3><form onsubmit="wd(event)"><select name="m"><option value="mvola">MVola</option><option value="orange">Orange Money</option><option value="airtel">Airtel Money</option></select><input name="p" placeholder="Numéro (ex : 0341234567)" pattern="0(32|33|34|37|38)[0-9]{7}" required><input name="a" type="number" min="20000" placeholder="Montant (Ar)" required><button class="btn gold">Demander le retrait</button></form></div>`}
 <div class="card"><h3>Dépôt</h3><button class="btn" onclick="modal(depForm())">Déposer (preuve de paiement)</button></div>
 <h2>Demandes de retrait</h2>${(wd.data||[]).map(x=>`<div class="card row"><span>${ar(x.amount)} · ${esc(x.method)}<br><small>${esc(x.phone)} · ${dt(x.created_at)}</small></span>${badge(x.status)}</div>`).join('')||'<p class="muted">Aucune.</p>'}
 <h2>Dépôts</h2>${(dp.data||[]).map(x=>`<div class="card row"><span>${ar(x.amount)}<br><small>${dt(x.created_at)}</small></span>${badge(x.status)}</div>`).join('')||'<p class="muted">Aucun.</p>'}
 <h2>Historique</h2>${(tx.data||[]).map(x=>`<div class="card row"><span>${esc(x.description)}<br><small>${dt(x.created_at)}</small></span><b class="${x.amount>=0?'pos':'neg'}">${x.amount>0?'+':''}${ar(x.amount)}</b></div>`).join('')||'<p class="muted">Aucun mouvement.</p>'}`)};
async function wd(e){e.preventDefault();const f=new FormData(e.target);try{await call('request_withdrawal',{p_amount:+f.get('a'),p_method:f.get('m'),p_phone:f.get('p')});toast('Demande enregistrée (simulation)');await loadMe();render()}catch{}}
routes.profile=async()=>{const biz=me.account_type==='business';const b=biz?(await sb.from('businesses').select('*').eq('owner_id',me.id).maybeSingle()).data||{}:null;
 view(`<div class="card"><h2>Mon profil</h2><p class="muted">${esc(me.email)} · ${biz?'Entreprise':'Utilisateur'}</p>
 <form onsubmit="saveP(event)"><input name="n" value="${esc(me.full_name)}" placeholder="Nom complet" required><input name="p" value="${esc(me.phone)}" placeholder="Téléphone"><button class="btn gold">Enregistrer</button></form></div>
 ${biz?`<div class="card"><h3>Informations de l'entreprise</h3><form onsubmit="saveB(event)"><input name="n" value="${esc(b.name)}" placeholder="Nom de l'entreprise" required><input name="s" value="${esc(b.sector)}" placeholder="Secteur d'activité"><input name="p" value="${esc(b.phone)}" placeholder="Téléphone professionnel"><textarea name="d" placeholder="Description">${esc(b.description)}</textarea><button class="btn gold">Enregistrer</button></form></div>`:''}
 <button class="btn bad" onclick="logout()">Déconnexion</button>`)};
async function saveP(e){e.preventDefault();const f=new FormData(e.target);const{error}=await sb.from('profiles').update({full_name:f.get('n'),phone:f.get('p')}).eq('id',me.id);if(error)return toast(error.message,1);toast('Profil mis à jour');await loadMe();render()}
