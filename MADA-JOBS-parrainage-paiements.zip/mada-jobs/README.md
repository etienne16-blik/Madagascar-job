# MADA JOBS — version 1

Site responsive en français, thème sombre élégant, prêt pour GitHub Pages + Supabase.

## Inclus
- Inscription et connexion e-mail / mot de passe (sans SMS)
- Tableau de bord, portefeuille en Ariary et historique
- Missions rémunérées 50 Ar après validation, avec limite serveur de 5 soumissions par jour
- Parrainage : code personnel et bonus de 500 Ar au parrain après validation de la première mission du filleul
- Retrait minimum de 10 000 Ar
- Demandes de dépôt et retrait, retrait minimum de 10 000 Ar
- Comptes particuliers et comptes entreprises / annonceurs
- Espace entreprise pour proposer des campagnes sponsorisées avec budget et nombre de participants
- Administration : créer/désactiver les missions, valider/refuser les preuves, demandes et propositions entreprises
- SQL avec RLS et fonctions serveur pour les validations

## Mise en service
1. Crée un projet sur https://supabase.com.
2. Nouvelle installation : exécute `supabase/schema.sql`. Si ton ancien MADA JOBS est déjà installé, exécute uniquement `supabase/upgrade-referral-and-wallet.sql` (ne relance pas le schéma initial complet).
3. Dans Authentication > URL Configuration, ajoute l'URL GitHub Pages du site.
4. Dans Authentication > Providers > Email, garde Email activé. Le SMS n'est pas utilisé.
5. Ouvre `config.js` et remplace `SUPABASE_URL` et `SUPABASE_ANON_KEY` par les valeurs Supabase (Project Settings > API).
6. Crée un compte via le site. Puis dans SQL Editor, attribue le rôle admin à ton e-mail :
   `update public.profiles set role='admin' where email='TON_EMAIL';`
7. Publie le contenu du dossier à la racine du dépôt GitHub `mada-jobs` (ne mets jamais de clé `service_role` dans le navigateur).
8. GitHub > Settings > Pages > Source : GitHub Actions. Le workflow fourni publie chaque commit sur `main`.

## Déploiement GitHub Pages
Le fichier `.github/workflows/deploy.yml` est inclus. Pousse le contenu sur la branche `main`. Le site sera publié sur :
`https://etienne16-blik.github.io/mada-jobs/`

## Important — argent réel et paiements
- Les entreprises peuvent proposer des campagnes sponsorisées ; les propositions sont en attente d'examen et ne publient pas automatiquement une mission.
- Les dépôts et retraits (minimum 10 000 Ar) sont des demandes enregistrées et traitées manuellement par un administrateur. Aucun paiement Mobile Money automatique n'est connecté.
- Un dépôt ne doit être approuvé qu'après réception réelle des fonds.
- Chaque mission validée crédite 50 Ar et le parrainage crédite 500 Ar après la première mission validée du filleul. Ces montants doivent être couverts par des fonds réellement disponibles avant validation.
- Le site ne génère pas d'argent automatiquement : les revenus doivent provenir de contrats sponsorisés, publicité ou offres professionnelles effectivement vendus.
- Avant lancement public, configure les règles de financement, les conditions d'utilisation, la confidentialité, la vérification anti-fraude et le support.
- Les fonctions de gestion du portefeuille sont sécurisées côté base de données et soumises au rôle admin. Ne partage jamais la clé Supabase `service_role`.

## Notes
Le nom de domaine d'assistance `*.example` est un placeholder à remplacer. Les coordonnées Mobile Money sont saisies par le membre, puis vérifiées par l'administration.
