routes.biz=async()=>{const{data}=await sb.from('campaigns').select('*').eq('owner_id',me.id).order('id',{ascending:false});
 const st=await Promise.all((data||[]).map(c=>sb.rpc('campaign_stats',{p_id:c.id}).then(r=>r.data||{})));
 view(`<h2>Mes campagnes</h2><div class="card"><h3>Nouvelle campagne</h3><form onsubmit="newCamp(event)">
 <input name="t" placeholder="Titre" required><textarea name="d" placeholder="Description / consigne"></textarea>
 <select name="y"><option value="social">Publication réseau social</option><option value="video">Vidéo sponsorisée</option><option value="screenshot">Capture d'écran</option><option value="ad">Publicité</option></select>
 <input name="u" type="url" placeholder="Lien de destination (https://…)"><input name="s" type="number" min="5" max="120" value="15" placeholder="Durée vidéo (s)">
 <input name="b" type="number" min="1000" placeholder="Budget (Ar, min. 1 000)" required><label class="muted">Image ou vidéo</label><input name="f" type="file" accept="image/*,video/mp4,video/webm">
 <button class="btn gold">Créer la campagne</button></form></div>
 ${(data||[]).map((c,i)=>`<div class="card"><div class="row"><b>${esc(c.title)}</b>${badge(c.status)}</div>
 <small>Budget demandé ${ar(c.budget)} · payé ${ar(c.budget_paid)} · dépensé ${ar(c.spent)}</small>
 <p class="muted">Missions validées : ${st[i].approved||0} · en attente : ${st[i].pending||0} · visionnages : ${st[i].views||0}</p>
 ${c.status==='active'?A('owner_set_campaign',{p_id:c.id,p_status:'paused'},'⏸ Mettre en pause'):''}${c.status==='paused'&&c.owner_paused?A('owner_set_campaign',{p_id:c.id,p_status:'active'},'▶ Reprendre','ok'):''}${c.budget_paid<=0?`<button class="btn sm gold" onclick="modal(depForm(${c.id},${c.budget}))">Payer / envoyer la preuve</button>`:''}</div>`).join('')}`)};
async function newCamp(e){e.preventDefault();const f=new FormData(e.target);try{const m=await upload(f.get('f'),'media');
 await call('create_campaign',{p_title:f.get('t'),p_desc:f.get('d'),p_type:f.get('y'),p_url:f.get('u')||null,p_media:m,p_budget:+f.get('b'),p_duration:+f.get('s')});toast('Campagne créée : effectuez le paiement');render()}catch{}}

async function saveB(e){e.preventDefault();const f=new FormData(e.target);const{error}=await sb.from('businesses').update({name:f.get('n'),sector:f.get('s'),phone:f.get('p'),description:f.get('d')}).eq('owner_id',me.id);if(error)return toast(error.message,1);toast('Entreprise mise à jour');render()}
