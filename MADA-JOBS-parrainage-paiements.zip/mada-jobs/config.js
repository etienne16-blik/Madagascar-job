// Supabase public browser credentials. Remplace les deux valeurs avant activation.
// La clé anon/publishable est destinée au navigateur. NE JAMAIS mettre une service_role ici.
window.MADA_CONFIG = {
  SUPABASE_URL: "https://TON-PROJET.supabase.co",
  SUPABASE_ANON_KEY: "TA_CLE_ANON_OU_PUBLISHABLE"
};