const cfg=window.MADA_CONFIG||{}, configured=cfg.SUPABASE_URL?.includes("supabase.co")&&!cfg.SUPABASE_URL.includes("TON-PROJET")&&cfg.SUPABASE_ANON_KEY&&!cfg.SUPABASE_ANON_KEY.startsWith("TA_CLE");
const db=configured?window.supabase.createClient(cfg.SUPABASE_URL,cfg.SUPABASE_ANON_KEY):null;
let user=null,profile=null,authMode="login",tasks=[],completions=[],requests=[],txs=[];
const $=id=>document.getElementById(id), money=n=>`${Number(n||0).toLocaleString("fr-FR")} Ar`, today=()=>new Date().toISOString().slice(0,10);
function toast(s){$("toast").textContent=s;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),3200)}
function msg(s){$("authMessage").textContent=s}
function showAuth(){ $("authView").classList.remove("hidden");$("appView").classList.add("hidden")}
function showApp(){ $("authView").classList.add("hidden");$("appView").classList.remove("hidden")}
function empty(s){return `<div class="empty">${s}</div>`}
function setMode(m){authMode=m;document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x.dataset.auth===m));$("nameWrap").classList.toggle("hidden",m!=="signup");$("accountTypeWrap").classList.toggle("hidden",m!=="signup");toggleBusinessSignup();$("referralWrap")?.classList.toggle("hidden",m!=="signup");$("authSubmit").innerHTML=m==="login"?'Se connecter <span>↗</span>':'Créer mon compte <span>↗</span>';msg("")}
function toggleBusinessSignup(){let isBusiness=authMode==="signup"&&$("accountType")?.value==="business";$("businessNameWrap")?.classList.toggle("hidden",!isBusiness)}
$("accountType")?.addEventListener("change",toggleBusinessSignup);
document.querySelectorAll("[data-auth]").forEach(b=>b.onclick=()=>setMode(b.dataset.auth));
$("authForm").onsubmit=async e=>{e.preventDefault();if(!db)return msg("Configuration Supabase manquante. Ouvre config.js et ajoute les clés du projet.");let email=$("email").value.trim(),password=$("password").value;
try{if(authMode==="signup"){let full_name=$("fullName").value.trim(),account_type=$("accountType").value,business_name=$("businessName").value.trim(),referral_code=$("referralCode").value.trim().toUpperCase();if(!full_name)return msg("Entre ton nom complet.");if(account_type==="business"&&!business_name)return msg("Entre le nom de ton entreprise.");let {data,error}=await db.auth.signUp({email,password,options:{data:{full_name,account_type,business_name,referral_code}}});if(error)throw error;if(data.session){toast("Compte créé !");await boot()}else msg("Compte créé. Vérifie ton e-mail si la confirmation est activée, puis connecte-toi.")}else{let {error}=await db.auth.signInWithPassword({email,password});if(error)throw error;await boot()}}catch(e){msg(e.message)}};
$("logout").onclick=async()=>{await db?.auth.signOut();user=null;showAuth()};
async function boot(){if(!db)return;let {data:{session}}=await db.auth.getSession();if(!session){showAuth();return}user=session.user;showApp();await loadData()}
async function loadData(){if(!user)return;
let [p,t,c,r,w]=await Promise.all([
 db.from("profiles").select("*").eq("id",user.id).single(),
 db.from("tasks").select("*").eq("active",true).order("created_at",{ascending:false}),
 db.from("task_completions").select("*").eq("user_id",user.id).order("created_at",{ascending:false}),
 db.from("wallet_requests").select("*").eq("user_id",user.id).order("created_at",{ascending:false}),
 db.from("wallet_transactions").select("*").eq("user_id",user.id).order("created_at",{ascending:false})
]);
if(p.error){toast("Profil introuvable : applique supabase/schema.sql");return}
profile=p.data;tasks=t.data||[];completions=c.data||[];requests=r.data||[];txs=w.data||[];
let name=profile.full_name||user.email.split("@")[0];$("welcomeName").textContent=name;$("avatar").textContent=name[0].toUpperCase();
let count=completions.filter(x=>x.completed_on===today()).length;$("todayCount").textContent=`${count} / 5`;$("taskLimit").textContent=`${count} / 5`;$("todayProgress").style.width=`${count/5*100}%`;$("taskNavCount").textContent=tasks.length;
$("balance").textContent=money(profile.balance);["depositBalance","withdrawBalance","transactionBalance"].forEach(id=>$(id).textContent=money(profile.balance));$("earned").textContent=money(profile.total_earned||0);
let isAdmin=profile.role==="admin",isBusiness=profile.role==="business";document.querySelectorAll(".admin-only").forEach(x=>x.classList.toggle("hidden",!isAdmin));document.querySelectorAll(".business-only").forEach(x=>x.classList.toggle("hidden",!isBusiness));
renderTasks();renderHistory();renderRequests();
await loadReferrals();if(isAdmin)await loadAdmin();if(isBusiness)await loadBusiness();
}
function completed(id){return completions.some(c=>String(c.task_id)===String(id)&&c.completed_on===today())}
function card(t){let done=completed(t.id),count=completions.filter(x=>x.completed_on===today()).length,blocked=count>=5;return `<article class="task-card"><div class="task-head"><span class="task-category">${esc(t.category||"Mission")}</span><span class="reward">+${money(50)}</span></div><h3>${esc(t.title)}</h3><p>${esc(t.description)}</p><div class="task-bottom"><small>${done?"Preuve envoyée aujourd'hui":blocked?"Limite quotidienne atteinte":"Récompense après validation"}</small><button data-task="${t.id}" ${done||blocked?"disabled":""}>${done?"Envoyée":blocked?"Demain":"Faire la mission ↗"}</button></div></article>`}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function renderTasks(){$("homeTasks").innerHTML=tasks.slice(0,2).map(card).join("")||empty("Aucune mission disponible pour le moment.");$("allTasks").innerHTML=tasks.map(card).join("")||empty("Les prochaines missions arrivent bientôt.");document.querySelectorAll("[data-task]").forEach(b=>b.onclick=()=>openProof(b.dataset.task))}
function openProof(id){let t=tasks.find(x=>String(x.id)===String(id));if(!t)return;$("proofTaskId").value=id;$("modalTitle").textContent=t.title;$("modalDescription").textContent=t.description;$("modal").classList.remove("hidden")}
$("modalClose").onclick=()=>$("modal").classList.add("hidden");$("modal").onclick=e=>{if(e.target===$("modal"))$("modal").classList.add("hidden")};
$("proofForm").onsubmit=async e=>{e.preventDefault();let task_id=Number($("proofTaskId").value),proof=$("proofText").value.trim();let {error}=await db.rpc("submit_task_proof",{p_task_id:task_id,p_proof:proof});if(error){toast(error.message);return} $("modal").classList.add("hidden");$("proofText").value="";toast("Preuve envoyée pour vérification.");await loadData()};
$("depositForm").onsubmit=async e=>{e.preventDefault();let amount=Number($("depositAmount").value),reference=$("depositRef").value.trim();if(amount<1000)return toast("Montant minimum : 1 000 Ar");let {error}=await db.from("wallet_requests").insert({user_id:user.id,type:"deposit",amount,details:reference});if(error)return toast(error.message);e.target.reset();toast("Demande de dépôt envoyée.");await loadData()};
$("withdrawForm").onsubmit=async e=>{e.preventDefault();let amount=Number($("withdrawAmount").value),phone=$("withdrawPhone").value.trim(),operator=$("withdrawOperator").value;if(amount<10000)return toast("Le retrait minimum est de 10 000 Ar.");if(amount>profile.balance)return toast("Solde insuffisant.");let {error}=await db.from("wallet_requests").insert({user_id:user.id,type:"withdrawal",amount,details:`${operator} — ${phone}`});if(error)return toast(error.message);e.target.reset();toast("Demande de retrait envoyée.");await loadData()};
function status(s){return `<span class="status ${s==="approved"?"approved":s==="rejected"?"rejected":""}">${s==="approved"?"Approuvée":s==="rejected"?"Refusée":"En attente"}</span>`}
function renderRequests(){let deposits=requests.filter(r=>r.type==="deposit"),withdrawals=requests.filter(r=>r.type==="withdrawal");const rows=list=>list.length?`<div class="table-row head"><span>Montant</span><span>État</span><span>Date</span></div>`+list.map(r=>`<div class="table-row"><b>${money(r.amount)}</b>${status(r.status)}<small>${new Date(r.created_at).toLocaleDateString("fr-FR")}</small></div>`).join(""):empty("Aucune demande pour le moment.");$("depositRequests").innerHTML=rows(deposits);$("withdrawRequests").innerHTML=rows(withdrawals);$("transactionRequestCount").textContent=requests.length;$("transactionCount").textContent=txs.length;}
function renderHistory(){let rows=txs.map(x=>({title:x.description||"Mouvement portefeuille",amount:x.amount,created_at:x.created_at})).sort((a,b)=>new Date(b.created_at)-new Date(a.created_at));$("historyList").innerHTML=rows.length?`<div class="table-row head"><span>Opération</span><span>Montant</span><span>Type</span><span>Date</span></div>`+rows.map(x=>`<div class="table-row"><span>${esc(x.title)}</span><b>${money(x.amount)}</b><span>Activité</span><small>${new Date(x.created_at).toLocaleDateString("fr-FR")}</small></div>`).join(""):empty("Aucune transaction financière confirmée pour le moment.")}
async function loadAdmin(){let [r,c,t]=await Promise.all([db.from("wallet_requests").select("*,profiles(full_name,email)").eq("status","pending").order("created_at"),db.from("task_completions").select("*,profiles(full_name,email),tasks(title,reward)").eq("status","pending").order("created_at"),db.from("tasks").select("*").order("created_at",{ascending:false})]);let pending=r.data||[],proofs=c.data||[],all=t.data||[];$("pendingCount").textContent=pending.length+proofs.length;$("activeMissionCount").textContent=all.filter(x=>x.active).length;$("adminRequests").innerHTML=pending.length?pending.map(x=>`<div class="table-row"><span>${esc(x.profiles?.full_name||x.profiles?.email||"Membre")} · ${x.type==="deposit"?"Dépôt":"Retrait"}</span><b>${money(x.amount)}</b><small>${esc(x.details)}</small><span>${status(x.status)} <button class="admin-action" data-request="${x.id}" data-decision="approved">Valider</button><button class="admin-action reject" data-request="${x.id}" data-decision="rejected">Refuser</button></span></div>`).join(""):empty("Aucune demande en attente.");
$("adminCompletions").innerHTML=proofs.length?proofs.map(x=>`<div class="table-row"><span>${esc(x.profiles?.full_name||x.profiles?.email||"Membre")} · ${esc(x.tasks?.title||"Mission")}</span><b>${money(x.tasks?.reward||0)}</b><small>${esc(x.proof||"")}</small><span><button class="admin-action" data-proof="${x.id}" data-decision="approved">Valider</button><button class="admin-action reject" data-proof="${x.id}" data-decision="rejected">Refuser</button></span></div>`).join(""):empty("Aucune preuve à vérifier.");
$("adminMissions").innerHTML=all.map(x=>`<div class="table-row"><span>${esc(x.title)}</span><b>${money(50)}</b><span>${x.active?"Active":"Inactive"}</span><button class="admin-action reject" data-toggle="${x.id}" data-active="${x.active}">${x.active?"Désactiver":"Activer"}</button></div>`).join("")||empty("Aucune mission.");
document.querySelectorAll("[data-request]").forEach(b=>b.onclick=async()=>{let {error}=await db.rpc("admin_review_wallet_request",{p_request_id:Number(b.dataset.request),p_status:b.dataset.decision});if(error)return toast(error.message);toast("Demande mise à jour.");await loadData()});
document.querySelectorAll("[data-proof]").forEach(b=>b.onclick=async()=>{let {error}=await db.rpc("admin_review_task_completion",{p_completion_id:Number(b.dataset.proof),p_status:b.dataset.decision});if(error)return toast(error.message);toast("Preuve traitée.");await loadData()});
document.querySelectorAll("[data-toggle]").forEach(b=>b.onclick=async()=>{let {error}=await db.from("tasks").update({active:b.dataset.active!=="true"}).eq("id",Number(b.dataset.toggle));if(error)return toast(error.message);await loadData()});
}
async function loadReferrals(){
 const code=profile.referral_code||"—";$("myReferralCode").textContent=code;
 let {data,error}=await db.from("referrals").select("id,status,created_at,rewarded_at").eq("referrer_id",user.id).order("created_at",{ascending:false});
 if(error){$("referralList").innerHTML=empty("Applique la mise à jour SQL du parrainage pour activer cette rubrique.");return}
 let rows=data||[];$("referralCount").textContent=rows.length;$("referralEarned").textContent=money(rows.filter(x=>x.status==="rewarded").length*500);
 $("referralList").innerHTML=rows.length?rows.map(x=>`<div class="table-row"><span>${"Filleul inscrit"}</span><b>${x.status==="rewarded"?"+500 Ar":"En attente de mission validée"}</b><small>${new Date(x.created_at).toLocaleDateString("fr-FR")}</small></div>`).join(""):empty("Tu n'as pas encore de filleul.");
}
$("copyReferral")?.addEventListener("click",async()=>{let code=profile?.referral_code;if(!code)return toast("Code indisponible.");try{await navigator.clipboard.writeText(code);toast("Code de parrainage copié !")}catch(e){toast("Ton code : "+code)}});

async function loadBusiness(){
 let {data,error}=await db.from("business_mission_requests").select("*").eq("business_id",user.id).order("created_at",{ascending:false});
 if(error){$("businessRequests").innerHTML=empty("Impossible de charger les campagnes : "+esc(error.message));return}
 let rows=data||[],pending=rows.filter(x=>x.status==="pending").length,live=rows.filter(x=>x.status==="approved").length;
 $("businessRequestCount").textContent=rows.length;$("businessPendingCount").textContent=pending;$("businessLiveCount").textContent=live;
 $("businessRequests").innerHTML=rows.length?rows.map(x=>`<div class="table-row"><span>${esc(x.title)}</span><b>${money(x.total_budget)}</b><span>${status(x.status)}</span><small>${new Date(x.created_at).toLocaleDateString("fr-FR")}</small></div>`).join(""):empty("Tu n'as pas encore proposé de campagne.");
}
$("businessMissionForm").onsubmit=async e=>{
 e.preventDefault();
 let reward=Number($("businessReward").value),slots=Number($("businessSlots").value),budget=Number($("businessBudget").value);
 if(reward*slots>budget)return toast("Le budget doit couvrir au minimum la récompense × participants.");
 let payload={business_id:user.id,company_name:profile.business_name||profile.full_name,title:$("businessMissionTitle").value.trim(),description:$("businessMissionDescription").value.trim(),reward_per_participant:reward,participant_limit:slots,total_budget:budget,url:$("businessUrl").value.trim()||null};
 let {error}=await db.from("business_mission_requests").insert(payload);
 if(error)return toast(error.message);
 e.target.reset();toast("Proposition envoyée pour examen.");await loadBusiness();
};
$("missionForm").onsubmit=async e=>{e.preventDefault();let payload={title:$("missionTitle").value.trim(),description:$("missionDescription").value.trim(),reward:50,category:$("missionCategory").value,url:$("missionUrl").value.trim()||null,active:true,created_by:user.id};let {error}=await db.from("tasks").insert(payload);if(error)return toast(error.message);e.target.reset();toast("Mission publiée.");await loadData()};
document.querySelectorAll("[data-page]").forEach(b=>b.onclick=()=>go(b.dataset.page));document.querySelectorAll("[data-goto]").forEach(b=>b.onclick=()=>go(b.dataset.goto));
function go(page){document.querySelectorAll(".page").forEach(x=>x.classList.add("hidden"));$("page-"+page)?.classList.remove("hidden");document.querySelectorAll("[data-page]").forEach(x=>x.classList.toggle("active",x.dataset.page===page));$("pageTitle").textContent=({home:"Tableau de bord",tasks:"Missions",deposit:"Dépôt",withdraw:"Retrait",transactions:"Transactions",referral:"Parrainage",business:"Espace entreprise",admin:"Administration"})[page]||"MADA JOBS";window.scrollTo(0,0)}
if(!configured){showAuth();msg("Pour activer le site, configure d'abord config.js et exécute supabase/schema.sql dans Supabase.");}
else{db.auth.onAuthStateChange(()=>setTimeout(boot,0));boot()}

$("copySite").onclick=async()=>{let link=location.href;try{await navigator.clipboard.writeText(link);toast("Lien du site copié !")}catch(e){let el=document.createElement("textarea");el.value=link;document.body.appendChild(el);el.select();document.execCommand("copy");el.remove();toast("Lien du site copié !")}};
