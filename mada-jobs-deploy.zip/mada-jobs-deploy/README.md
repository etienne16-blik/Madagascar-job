# MADA JOBS

Plateforme de missions publicitaires (HTML/CSS/JS + Supabase).  
**Tous les soldes et retraits sont virtuels (simulation).**

## Déploiement (site statique)

### 1. Configurer Supabase
1. Créez un projet sur [supabase.com](https://supabase.com)
2. **SQL Editor** → exécutez le fichier `20241114000000_initial_schema.sql` (fourni séparément dans le dossier `supabase/migrations/`)
3. **Authentication > Providers > Email** → activez (désactivez « Confirm email » pour tester vite)
4. **Settings > API** → copiez l’URL et la clé `anon`

### 2. Configurer l’application
Ouvrez `js/config.js` et remplacez :

```js
const CFG = {
  SUPABASE_URL: 'https://VOTRE-PROJET.supabase.co',
  SUPABASE_ANON_KEY: 'VOTRE_CLE_ANON',
  MVOLA_NUM: '0382830494',
  MVOLA_NAME: 'Marolahy'
};
```

### 3. Créer le compte admin
1. Créez votre compte dans l’application
2. Dans le SQL Editor Supabase :
```sql
insert into admin_roles(user_id)
select id from auth.users where email = 'VOTRE_EMAIL';
```
3. Reconnectez-vous → l’onglet **Admin** apparaît

### 4. Déployer le site

**Netlify (recommandé)**
- Allez sur [netlify.com](https://netlify.com) → « Add new site » → « Deploy manually »
- Glissez-déposez ce dossier entier

**GitHub Pages**
- Poussez le dossier sur un repo GitHub
- Settings → Pages → Branch : `main` / root

**Vercel / Cloudflare Pages**
- Même principe : importer le dossier (site statique, pas de build)

### Test rapide
- Utilisateur : faire une mission → Admin > Preuves > Valider → +100 Ar
- Entreprise : créer une campagne → Payer → Admin > Dépôts > Valider
- Retrait : minimum 20 000 Ar

## Structure du dossier
```
├── index.html
├── css/style.css
├── js/
│   ├── config.js      ← à configurer
│   ├── app.js
│   ├── business.js
│   └── admin.js
└── README.md
```
