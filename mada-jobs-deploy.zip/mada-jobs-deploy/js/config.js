// Remplacez par les valeurs de votre projet Supabase (Settings > API).
// La clé "anon" est publique par conception : la sécurité repose sur RLS + fonctions SQL.
const CFG={SUPABASE_URL:'https://VOTRE-PROJET.supabase.co',SUPABASE_ANON_KEY:'VOTRE_CLE_ANON',MVOLA_NUM:'0382830494',MVOLA_NAME:'Marolahy'};
